# 🌬️ UK Wind Forecast Monitor

Full-stack web app for the REint Full Stack SWE Challenge — monitor UK national wind power generation forecasts vs actuals.

> **AI Disclosure:** Claude (Anthropic) was used as an AI coding assistant. Analysis logic and interpretations in the notebooks are original.

---

## 📁 Directory Structure

```
wind-forecast-app/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Main dashboard UI
│   │   ├── layout.tsx            # Root layout + metadata
│   │   ├── globals.css           # Global styles
│   │   └── api/wind-data/
│   │       └── route.ts          # API: fetches & merges Elexon data
│   ├── components/
│   │   ├── WindChart.tsx         # Recharts line chart
│   │   └── StatsPanel.tsx        # Error metrics (MAE, RMSE, Bias, P99)
│   └── lib/
│       └── types.ts              # TypeScript types + utility functions
├── notebooks/
│   ├── 01_forecast_error_analysis.ipynb    # Part 2a: Error characteristics
│   └── 02_wind_reliability_analysis.ipynb  # Part 2b: Reliability recommendation
├── vercel.json
└── README.md
```

---

## 🚀 How to Start

### Prerequisites: Node.js 18+, npm 9+

```bash
npm install
npm run dev
# Open http://localhost:3000
```

### Production
```bash
npm run build && npm start
```

---

## 🌐 Deploy to Vercel

```bash
npm install -g vercel
vercel --prod
```

---

## 📊 Jupyter Notebooks

```bash
pip install jupyter pandas numpy matplotlib seaborn requests
cd notebooks && jupyter notebook
```

| Notebook | Description |
|---|---|
| `01_forecast_error_analysis.ipynb` | MAE, RMSE, P99, bias by horizon (0–48h) and hour-of-day |
| `02_wind_reliability_analysis.ipynb` | Actual generation analysis; P10 reliable MW recommendation |

---

## 🛠 Tech Stack

| | Technology | Version |
|---|---|---|
| Framework | Next.js | 16.1.6 |
| Language | TypeScript | 5.x |
| Styling | Tailwind CSS | 4.x |
| Charts | Recharts | 3.8.0 |
| Dates | date-fns | 4.1.0 |
| Deploy | Vercel | — |
| Analysis | Python / Jupyter | 3.12 |

---

## ✨ App Features

- 📅 Start/end datetime pickers (Jan 2024 data)
- 🎚️ Forecast horizon slider (0–48h)
- ⚡ Quick-select range buttons
- 📈 Interactive line chart: Actual (blue) vs Forecast (green dashed)
- 🔢 Error metrics: MAE, RMSE, Bias, P99
- 📱 Fully responsive — mobile + desktop
- 🌑 Dark theme
