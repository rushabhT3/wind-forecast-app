import { NextRequest, NextResponse } from "next/server";

const FUELHH_URL =
  "https://data.elexon.co.uk/bmrs/api/v1/datasets/FUELHH/stream";
const WINDFOR_URL =
  "https://data.elexon.co.uk/bmrs/api/v1/datasets/WINDFOR/stream";

interface FuelHHRecord {
  startTime: string;
  fuelType: string;
  generation: number;
}

interface WindForRecord {
  startTime: string;
  publishTime: string;
  generation: number;
}

async function fetchAllPages<T>(
  url: string,
  params: Record<string, string>
): Promise<T[]> {
  const searchParams = new URLSearchParams(params);
  const fullUrl = `${url}?${searchParams.toString()}`;

  const response = await fetch(fullUrl, {
    headers: { Accept: "application/json" },
    next: { revalidate: 300 }, // cache 5 min
  });

  if (!response.ok) {
    throw new Error(`HTTP error ${response.status} for ${fullUrl}`);
  }

  const data = await response.json();
  // Elexon stream API returns array directly
  return Array.isArray(data) ? data : data.data ?? [];
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const from = searchParams.get("from"); // ISO string
  const to = searchParams.get("to"); // ISO string
  const horizonHours = parseInt(searchParams.get("horizon") ?? "4", 10);

  if (!from || !to) {
    return NextResponse.json(
      { error: "from and to params required" },
      { status: 400 }
    );
  }

  try {
    // Fetch actual wind generation (FUELHH - fuel half-hourly)
    const actualData = await fetchAllPages<FuelHHRecord>(FUELHH_URL, {
      from,
      to,
      fuelType: "WIND",
    });

    // Fetch wind forecasts (WINDFOR)
    // We need publishTime window: from - 48h to to - 0h
    const fromDate = new Date(from);
    const toDate = new Date(to);
    // Extend publish window to capture 0-48h horizon forecasts
    const publishFrom = new Date(
      fromDate.getTime() - 48 * 60 * 60 * 1000
    ).toISOString();
    const publishTo = toDate.toISOString();

    const forecastData = await fetchAllPages<WindForRecord>(WINDFOR_URL, {
      from: publishFrom,
      to: publishTo,
    });

    // Filter actuals to WIND only (API param should do it but double-check)
    const windActuals = actualData.filter(
      (r) => r.fuelType === "WIND" || !r.fuelType
    );

    // Build actuals map: startTime -> generation
    const actualsMap = new Map<string, number>();
    for (const record of windActuals) {
      const key = new Date(record.startTime).toISOString();
      actualsMap.set(key, record.generation);
    }

    // Filter forecasts: horizon between 0-48h
    // For each target startTime in [from, to], find latest forecast
    // where publishTime <= startTime - horizonHours
    const forecastsInRange = forecastData.filter((r) => {
      const targetTime = new Date(r.startTime).getTime();
      const publishTime = new Date(r.publishTime).getTime();
      const horizonMs = (targetTime - publishTime) / (1000 * 60 * 60);
      return (
        horizonMs >= 0 &&
        horizonMs <= 48 &&
        targetTime >= fromDate.getTime() &&
        targetTime <= toDate.getTime()
      );
    });

    // Group forecasts by startTime, then pick latest publishTime
    // that satisfies: publishTime <= startTime - horizonHours
    const forecastsByTarget = new Map<string, WindForRecord[]>();
    for (const record of forecastsInRange) {
      const key = new Date(record.startTime).toISOString();
      if (!forecastsByTarget.has(key)) forecastsByTarget.set(key, []);
      forecastsByTarget.get(key)!.push(record);
    }

    const latestForecasts = new Map<string, number>();
    for (const [targetKey, records] of forecastsByTarget.entries()) {
      const targetTime = new Date(targetKey).getTime();
      const cutoffTime = targetTime - horizonHours * 60 * 60 * 1000;

      // Only forecasts published at or before cutoff
      const eligible = records.filter(
        (r) => new Date(r.publishTime).getTime() <= cutoffTime
      );

      if (eligible.length === 0) continue;

      // Pick the latest publishTime among eligible
      eligible.sort(
        (a, b) =>
          new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime()
      );
      latestForecasts.set(targetKey, eligible[0].generation);
    }

    // Build unified time series sorted by time
    const allTimes = new Set<string>();
    actualsMap.forEach((_, k) => allTimes.add(k));
    latestForecasts.forEach((_, k) => allTimes.add(k));

    const sortedTimes = Array.from(allTimes).sort();

    const series = sortedTimes.map((time) => ({
      time,
      actual: actualsMap.has(time) ? actualsMap.get(time) : null,
      forecast: latestForecasts.has(time)
        ? latestForecasts.get(time)
        : null,
    }));

    return NextResponse.json({ series, count: series.length });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
