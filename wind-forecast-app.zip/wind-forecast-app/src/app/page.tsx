"use client";

import { useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { format } from "date-fns";
import { ApiResponse, DataPoint } from "@/lib/types";
import StatsPanel from "@/components/StatsPanel";

const WindChart = dynamic(() => import("@/components/WindChart"), {
  ssr: false,
  loading: () => (
    <div className="h-[420px] flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-[#58a6ff] border-t-transparent rounded-full animate-spin" />
    </div>
  ),
});

const DEFAULT_FROM = "2024-01-01T00:00";
const DEFAULT_TO   = "2024-01-08T00:00";

export default function Home() {
  const [fromInput, setFromInput] = useState(DEFAULT_FROM);
  const [toInput,   setToInput]   = useState(DEFAULT_TO);
  const [horizon,   setHorizon]   = useState(4);
  const [data,      setData]      = useState<DataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState<string | null>(null);
  const [hasFetched,setHasFetched]= useState(false);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const from = new Date(fromInput).toISOString();
      const to   = new Date(toInput).toISOString();
      const url  = `/api/wind-data?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&horizon=${horizon}`;
      const res  = await fetch(url);
      const json: ApiResponse = await res.json();
      if (!res.ok || json.error) throw new Error(json.error ?? "Request failed");
      setData(json.series);
      setHasFetched(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setIsLoading(false);
    }
  }, [fromInput, toInput, horizon]);

  const quickRanges = [
    { label: "Jan 1–3",  from: "2024-01-01T00:00", to: "2024-01-04T00:00" },
    { label: "Jan 7–14", from: "2024-01-07T00:00", to: "2024-01-14T00:00" },
    { label: "Jan 15–22",from: "2024-01-15T00:00", to: "2024-01-22T00:00" },
    { label: "Jan 2024", from: "2024-01-01T00:00", to: "2024-02-01T00:00" },
  ];

  return (
    <main className="min-h-screen bg-[#0d1117] text-[#c9d1d9]" style={{ fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>
      {/* Header */}
      <header className="border-b border-[#21262d] bg-[#010409]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#58a6ff] to-[#3fb950] flex items-center justify-center text-xl">🌬️</div>
              <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#3fb950] border-2 border-[#010409] animate-pulse" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white">UK Wind Forecast Monitor</h1>
              <p className="text-[#8b949e] text-xs">National Grid · Jan 2024 · Elexon BMRS</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-3 text-xs text-[#8b949e]">
            <span className="flex items-center gap-1.5"><span className="w-4 h-0.5 bg-[#58a6ff] inline-block rounded"/>Actual</span>
            <span className="flex items-center gap-1.5"><span className="w-4 h-px bg-[#3fb950] inline-block border-t-2 border-dashed border-[#3fb950]"/>Forecast</span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-5">

        {/* Controls card */}
        <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-5">
          <div className="flex flex-wrap gap-4 items-end">

            <div className="flex flex-col gap-1.5 flex-1 min-w-[170px]">
              <label className="text-[#8b949e] text-xs uppercase tracking-widest">Start Time</label>
              <input type="datetime-local" value={fromInput}
                min="2024-01-01T00:00" max="2024-01-31T23:30"
                onChange={e => setFromInput(e.target.value)}
                className="bg-[#0d1117] border border-[#30363d] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-[#58a6ff] transition-colors" />
            </div>

            <div className="flex flex-col gap-1.5 flex-1 min-w-[170px]">
              <label className="text-[#8b949e] text-xs uppercase tracking-widest">End Time</label>
              <input type="datetime-local" value={toInput}
                min="2024-01-01T00:00" max="2024-02-01T00:00"
                onChange={e => setToInput(e.target.value)}
                className="bg-[#0d1117] border border-[#30363d] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-[#58a6ff] transition-colors" />
            </div>

            <div className="flex flex-col gap-1.5 flex-1 min-w-[200px]">
              <label className="text-[#8b949e] text-xs uppercase tracking-widest flex justify-between">
                <span>Forecast Horizon</span>
                <span className="text-[#58a6ff] font-bold">{horizon}h</span>
              </label>
              <div className="flex items-center gap-3">
                <span className="text-xs text-[#484f58]">0h</span>
                <input type="range" min={0} max={48} step={1} value={horizon}
                  onChange={e => setHorizon(Number(e.target.value))}
                  className="flex-1 h-2 rounded-full appearance-none bg-[#21262d] cursor-pointer"
                  style={{ accentColor: "#58a6ff" }} />
                <span className="text-xs text-[#484f58]">48h</span>
              </div>
              <p className="text-[#484f58] text-xs">Forecasts published ≥ {horizon}h before target</p>
            </div>

            <button onClick={fetchData} disabled={isLoading}
              className="bg-[#238636] hover:bg-[#2ea043] disabled:bg-[#21262d] disabled:cursor-not-allowed text-white px-6 py-2.5 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 min-w-[130px] justify-center whitespace-nowrap">
              {isLoading
                ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"/>Loading…</>
                : <><span>⚡</span>Fetch Data</>}
            </button>
          </div>

          {/* Quick ranges */}
          <div className="mt-4 flex flex-wrap gap-2 items-center">
            <span className="text-[#484f58] text-xs">Quick:</span>
            {quickRanges.map(qr => (
              <button key={qr.label}
                onClick={() => { setFromInput(qr.from); setToInput(qr.to); }}
                className="text-xs px-3 py-1 rounded-full border border-[#30363d] text-[#8b949e] hover:border-[#58a6ff] hover:text-[#58a6ff] transition-all">
                {qr.label}
              </button>
            ))}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-[#2d1117] border border-[#f85149] rounded-lg px-4 py-3 text-[#f85149] text-sm flex items-start gap-2">
            <span>⚠️</span>
            <div>
              <p className="font-semibold">Error fetching data</p>
              <p className="text-xs mt-0.5 text-[#ffa198]">{error}</p>
            </div>
          </div>
        )}

        {/* Chart card */}
        <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-[#c9d1d9] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#3fb950] inline-block animate-pulse"/>
              Generation vs Forecast
            </h2>
            {data.length > 0 && (
              <span className="text-xs text-[#484f58]">
                {data.length} pts · {horizon}h horizon
              </span>
            )}
          </div>
          <WindChart data={data} isLoading={isLoading} />
        </div>

        {/* Error metrics */}
        {hasFetched && (
          <div>
            <h2 className="text-xs uppercase tracking-widest text-[#8b949e] mb-3">Error Metrics</h2>
            <StatsPanel data={data} />
          </div>
        )}

        {/* Info footer */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-[#484f58]">
          <div className="bg-[#161b22] border border-[#21262d] rounded-lg p-4">
            <p className="font-semibold text-[#8b949e] mb-1">Data Sources</p>
            <p>Actual: FUELHH (fuelType=WIND) · Forecast: WINDFOR</p>
            <p className="mt-1">Elexon BMRS API · January 2024 · UTC timestamps</p>
          </div>
          <div className="bg-[#161b22] border border-[#21262d] rounded-lg p-4">
            <p className="font-semibold text-[#8b949e] mb-1">Horizon Logic</p>
            <p>For target time T, latest forecast with publishTime ≤ T − {horizon}h is shown. Horizon range 0–48h.</p>
          </div>
        </div>

        <p className="text-center text-[#30363d] text-xs pb-4">
          Next.js 16.1 · Recharts 3.8.0 · date-fns 4.1.0
        </p>
      </div>
    </main>
  );
}
