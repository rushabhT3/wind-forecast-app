"use client";

import { useMemo } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";
import { format, parseISO } from "date-fns";
import { DataPoint, formatAxisMW, formatMW } from "@/lib/types";

interface Props {
  data: DataPoint[];
  isLoading: boolean;
}

interface TooltipPayload {
  name: string;
  value: number | null;
  color: string;
  dataKey: string;
}

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}) {
  if (!active || !payload?.length || !label) return null;

  const actual = payload.find((p) => p.dataKey === "actual");
  const forecast = payload.find((p) => p.dataKey === "forecast");
  const error =
    actual?.value != null && forecast?.value != null
      ? forecast.value - actual.value
      : null;

  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded-lg p-3 shadow-xl text-sm min-w-[200px]">
      <p className="text-[#8b949e] font-mono text-xs mb-2">
        {format(parseISO(label), "dd MMM yyyy HH:mm")} UTC
      </p>
      {actual?.value != null && (
        <div className="flex justify-between gap-4 mb-1">
          <span className="text-[#58a6ff] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#58a6ff] inline-block" />
            Actual
          </span>
          <span className="text-white font-mono font-semibold">
            {formatMW(actual.value)}
          </span>
        </div>
      )}
      {forecast?.value != null && (
        <div className="flex justify-between gap-4 mb-1">
          <span className="text-[#3fb950] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#3fb950] inline-block" />
            Forecast
          </span>
          <span className="text-white font-mono font-semibold">
            {formatMW(forecast.value)}
          </span>
        </div>
      )}
      {error != null && (
        <div className="mt-2 pt-2 border-t border-[#30363d] flex justify-between gap-4">
          <span className="text-[#8b949e]">Error</span>
          <span
            className={`font-mono font-semibold ${
              Math.abs(error) < 500
                ? "text-[#3fb950]"
                : Math.abs(error) < 1500
                ? "text-[#d29922]"
                : "text-[#f85149]"
            }`}
          >
            {error > 0 ? "+" : ""}
            {formatMW(error)}
          </span>
        </div>
      )}
    </div>
  );
}

export default function WindChart({ data, isLoading }: Props) {
  const chartData = useMemo(
    () =>
      data.map((d) => ({
        ...d,
        actual: d.actual,
        forecast: d.forecast,
      })),
    [data]
  );

  const yDomain = useMemo(() => {
    const vals: number[] = [];
    for (const d of data) {
      if (d.actual != null) vals.push(d.actual);
      if (d.forecast != null) vals.push(d.forecast);
    }
    if (vals.length === 0) return [0, 20000];
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const pad = (max - min) * 0.1;
    return [Math.max(0, Math.floor((min - pad) / 500) * 500), Math.ceil((max + pad) / 500) * 500];
  }, [data]);

  const tickFormatter = (val: string) => {
    try {
      return format(parseISO(val), "HH:mm\ndd/MM");
    } catch {
      return val;
    }
  };

  if (isLoading) {
    return (
      <div className="w-full h-[420px] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-[#58a6ff] border-t-transparent rounded-full animate-spin" />
          <p className="text-[#8b949e] text-sm animate-pulse">
            Fetching generation data…
          </p>
        </div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="w-full h-[420px] flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4">🌬️</div>
          <p className="text-[#8b949e]">No data — select a date range and click Fetch</p>
        </div>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={420}>
      <LineChart
        data={chartData}
        margin={{ top: 10, right: 20, left: 10, bottom: 40 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#21262d" />
        <XAxis
          dataKey="time"
          tickFormatter={tickFormatter}
          tick={{ fill: "#8b949e", fontSize: 11, fontFamily: "monospace" }}
          axisLine={{ stroke: "#30363d" }}
          tickLine={{ stroke: "#30363d" }}
          interval="preserveStartEnd"
          minTickGap={60}
          label={{
            value: "Target Time (UTC)",
            position: "insideBottom",
            offset: -30,
            fill: "#8b949e",
            fontSize: 12,
          }}
        />
        <YAxis
          domain={yDomain}
          tickFormatter={formatAxisMW}
          tick={{ fill: "#8b949e", fontSize: 11, fontFamily: "monospace" }}
          axisLine={{ stroke: "#30363d" }}
          tickLine={{ stroke: "#30363d" }}
          label={{
            value: "Power (MW)",
            angle: -90,
            position: "insideLeft",
            offset: 10,
            fill: "#8b949e",
            fontSize: 12,
          }}
        />
        <Tooltip
          content={<CustomTooltip />}
          cursor={{ stroke: "#30363d", strokeWidth: 1, strokeDasharray: "4 4" }}
        />
        <Legend
          verticalAlign="top"
          align="right"
          formatter={(value: string) => (
            <span style={{ color: "#c9d1d9", fontSize: 12 }}>
              {value === "actual" ? "Actual" : "Forecast"}
            </span>
          )}
        />
        <ReferenceLine y={0} stroke="#30363d" />
        <Line
          type="monotone"
          dataKey="actual"
          stroke="#58a6ff"
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4, fill: "#58a6ff" }}
          connectNulls={false}
          name="actual"
        />
        <Line
          type="monotone"
          dataKey="forecast"
          stroke="#3fb950"
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4, fill: "#3fb950" }}
          connectNulls={false}
          strokeDasharray="6 2"
          name="forecast"
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
