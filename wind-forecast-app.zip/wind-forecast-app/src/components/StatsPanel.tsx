"use client";

import { DataPoint, calcStats, formatMW } from "@/lib/types";

export default function StatsPanel({ data }: { data: DataPoint[] }) {
  const stats = calcStats(data);

  if (!stats) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {["MAE", "RMSE", "Bias", "P99 Error"].map((label) => (
          <div key={label} className="bg-[#161b22] border border-[#30363d] rounded-lg p-4">
            <p className="text-[#8b949e] text-xs uppercase tracking-widest mb-1">{label}</p>
            <p className="text-[#484f58] text-xl font-mono font-bold">—</p>
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      label: "MAE",
      value: formatMW(stats.mae),
      sub: "Mean Absolute Error",
      color: "text-[#58a6ff]",
    },
    {
      label: "RMSE",
      value: formatMW(stats.rmse),
      sub: "Root Mean Sq. Error",
      color: "text-[#bc8cff]",
    },
    {
      label: "Bias",
      value: `${stats.bias >= 0 ? "+" : ""}${formatMW(stats.bias)}`,
      sub: stats.bias > 0 ? "Over-forecasting" : "Under-forecasting",
      color: Math.abs(stats.bias) < 200 ? "text-[#3fb950]" : "text-[#d29922]",
    },
    {
      label: "P99 Error",
      value: formatMW(stats.p99),
      sub: `Over ${stats.count} matched pts`,
      color: "text-[#f85149]",
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {cards.map((card) => (
        <div
          key={card.label}
          className="bg-[#161b22] border border-[#30363d] rounded-lg p-4 hover:border-[#58a6ff] transition-colors"
        >
          <p className="text-[#8b949e] text-xs uppercase tracking-widest mb-1">
            {card.label}
          </p>
          <p className={`text-xl font-mono font-bold ${card.color}`}>
            {card.value}
          </p>
          <p className="text-[#484f58] text-xs mt-1">{card.sub}</p>
        </div>
      ))}
    </div>
  );
}
