export interface DataPoint {
  time: string;
  actual: number | null;
  forecast: number | null;
}

export interface ApiResponse {
  series: DataPoint[];
  count: number;
  error?: string;
}

export function formatMW(value: number): string {
  if (value >= 1000) return `${(value / 1000).toFixed(1)}GW`;
  return `${Math.round(value)}MW`;
}

export function formatAxisMW(value: number): string {
  if (value >= 1000) return `${(value / 1000).toFixed(0)}k`;
  return `${Math.round(value)}`;
}

export function calcStats(points: DataPoint[]) {
  const errors: number[] = [];
  for (const p of points) {
    if (p.actual != null && p.forecast != null) {
      errors.push(p.forecast - p.actual);
    }
  }
  if (errors.length === 0) return null;

  const absErrors = errors.map(Math.abs);
  const mae = absErrors.reduce((a, b) => a + b, 0) / absErrors.length;
  const rmse = Math.sqrt(
    errors.map((e) => e * e).reduce((a, b) => a + b, 0) / errors.length
  );
  const sorted = [...absErrors].sort((a, b) => a - b);
  const p99 = sorted[Math.floor(sorted.length * 0.99)] ?? sorted[sorted.length - 1];

  // Bias: mean signed error
  const bias = errors.reduce((a, b) => a + b, 0) / errors.length;

  return { mae, rmse, p99, bias, count: errors.length };
}
